/* ••••••••••••••••••••••••••••••••••••••••••••••••••••• */
/* UNIVERSAL MODE ACTIVE                                     */
/* Edit inject-to/universal.js for changes on all sites.     */
/* ••••••••••••••••••••••••••••••••••••••••••••••••••••• */
const injectTo = [];