/* •••••••••••••••••••••••••••••••••••••••••••••••••••••••••••• */
/* Right here, you have access to the `injector` global object. */
/* So you can inject unlimited codes using: ••••••••••••••••••• */
/* injector.injectInlineJs(); ••••••••••••••••••••••••••••••••• */
/* injector.injectExternalJs(); ••••••••••••••••••••••••••••••• */
/* injector.injectInternalCss(); •••••••••••••••••••••••••••••• */
/* injector.injectExternalCss(); •••••••••••••••••••••••••••••• */
/* Anyway it's OPTIONAL, you can also define your logic. •••••• */
/* •••••••••••••••••••••••••••••••••••••••••••••••••••••••••••• */
/* •••••••••••••••••••••••••••••••••••••••••••••••••••••••••••• */
/* Universal injection - runs on ALL domains */
/* Customize this file for your global effects! */
/* •••••••••••••••••••••••••••••••••••••••••••••••••••••••••••• */
console.log('🚀 Injector+ Universal Mode Active on this page!');
/* •••••••••••••••••••••••••••••••••••••••••••••••••••••••••••• */
/* Universal injection with WebGL + Advanced Anti-Fingerprint */
/* Spoofing + Rich Hardware (256 cores, 6TB RAM class) */
/* •••••••••••••••••••••••••••••••••••••••••••••••••••••••••••• */
injector.injectInlineJs(`
    console.log('🚀 Injector+ Universal script starting...');

    // Remove unwanted window properties
    (function cleanupWindowProps() {
        const badProps = ['_ic_event_super_props', '__do_not_use_me_isNodeRendered', 'ADBLOCK_DETECTED', '_rollbarWrappedError', '_rollbarInitialized'];
        badProps.forEach(prop => {
            if (prop in window) delete window[prop];
        });
        if (window.user_channel_props) delete window.user_channel_props.user_channel_1;
        console.log('✅ Unwanted window properties cleaned');
    })();

    // Spoof language to common English
    Object.defineProperty(navigator, 'language', { get: () => 'en-US', configurable: true });
    Object.defineProperty(navigator, 'languages', { get: () => ['en-US', 'en'], configurable: true });

    // UA spoof to clean Windows Chrome
    const chromeVersion = '149.0.0.0';
    const newUA = \`Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/\${chromeVersion} Safari/537.36\`;
    Object.defineProperty(navigator, 'userAgent', { get: () => newUA, configurable: true });
    Object.defineProperty(navigator, 'appVersion', { get: () => newUA, configurable: true });

    // Page always visible
    (function spoofVisibility() {
        Object.defineProperty(document, 'visibilityState', { get: () => 'visible', configurable: true });
        Object.defineProperty(document, 'hidden', { get: () => false, configurable: true });
        const origAdd = document.addEventListener;
        document.addEventListener = function(type, listener, options) {
            if (type === 'visibilitychange') return;
            return origAdd.apply(this, arguments);
        };
        console.log('✅ Page always appears visible');
    })();

    // CSS protection for max-device-width/height
    injector.injectInternalCss(\`
        @media (max-device-width: 99999px) { }
        @media (max-device-height: 99999px) { }
    \`);

    // ========================================================
    // 1. RICH HARDWARE SPOOFING (256 CPU cores, 6TB RAM class)
    // ========================================================
    (function spoofRichHardware() {
        try {
            Object.defineProperty(navigator, 'hardwareConcurrency', {
                get: () => 256,
                configurable: true,
                enumerable: true
            });
        } catch(e) {}
        if ('deviceMemory' in navigator) {
            try {
                Object.defineProperty(navigator, 'deviceMemory', {
                    get: () => 6144,
                    configurable: true,
                    enumerable: true
                });
            } catch(e) {}
        }
        if (window.performance && performance.memory) {
            try {
                Object.defineProperty(performance, 'memory', {
                    get: () => ({
                        jsHeapSizeLimit: 68719476736,
                        totalJSHeapSize: 8589934592,
                        usedJSHeapSize: 2147483648
                    }),
                    configurable: true
                });
            } catch(e) {}
        }
        console.log('✅ Rich Hardware Spoofed: 256 cores, 6TB RAM class');
    })();
    // ========================================================
    // TIMEZONE + TIME NOISE (Seattle + up to ±3s)
    // ========================================================
    (function spoofTimeAndTimezone() {
        const seattleTz = 'America/Los_Angeles';
        const origDateTimeFormat = Intl.DateTimeFormat;
        Intl.DateTimeFormat = function(locales, options) {
            options = options || {};
            options.timeZone = seattleTz;
            return origDateTimeFormat.call(this, locales, options);
        };
        Intl.DateTimeFormat.prototype = origDateTimeFormat.prototype;
        const origNow = Date.now;
        let timeNoise = (Math.random() - 0.5) * 6000;
        Date.now = function() {
            return Math.floor(origNow() + timeNoise);
        };
        const origGetTime = Date.prototype.getTime;
        Date.prototype.getTime = function() {
            return Math.floor(origGetTime.call(this) + timeNoise);
        };
        console.log('✅ Timezone spoofed to Seattle + time noise (±3s)');
    })();
    // ========================================================
    // 2. CANVAS + FONT FINGERPRINT PROTECTION (VERY STRONG)
    // ========================================================
    (function spoofCanvas() {
        const origGetImageData = CanvasRenderingContext2D.prototype.getImageData;
        CanvasRenderingContext2D.prototype.getImageData = function(sx, sy, sw, sh, settings) {
            const imageData = origGetImageData.apply(this, arguments);
            const data = imageData.data;
            const noise = 5;
            for (let i = 0; i < data.length; i += 4) {
                data[i] = Math.max(0, Math.min(255, data[i] + (Math.random() * noise * 2 - noise)));
                data[i + 1] = Math.max(0, Math.min(255, data[i + 1] + (Math.random() * noise * 2 - noise)));
                data[i + 2] = Math.max(0, Math.min(255, data[i + 2] + (Math.random() * noise * 2 - noise)));
            }
            return imageData;
        };
        const origToDataURL = HTMLCanvasElement.prototype.toDataURL;
        HTMLCanvasElement.prototype.toDataURL = function(type, quality) {
            return origToDataURL.apply(this, arguments);
        };
        const origToBlob = HTMLCanvasElement.prototype.toBlob;
        HTMLCanvasElement.prototype.toBlob = function(callback, type, quality) {
            return origToBlob.apply(this, arguments);
        };
        const origFillText = CanvasRenderingContext2D.prototype.fillText;
        CanvasRenderingContext2D.prototype.fillText = function(text, x, y, maxWidth) {
            const offsetX = (Math.random() - 0.5) * 1.5;
            const offsetY = (Math.random() - 0.5) * 1.5;
            return origFillText.call(this, text, x + offsetX, y + offsetY, maxWidth);
        };
        console.log('✅ Very strong Canvas + Font protection active');
    })();
    // ========================================================
    // 3. AUDIO FINGERPRINT PROTECTION (with noise)
    // ========================================================
    (function spoofAudio() {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return;
        const origCreateAnalyser = AC.prototype.createAnalyser;
        AC.prototype.createAnalyser = function() {
            const analyser = origCreateAnalyser.apply(this, arguments);
            const origGetFloatFrequencyData = analyser.getFloatFrequencyData;
            analyser.getFloatFrequencyData = function(array) {
                origGetFloatFrequencyData.apply(this, arguments);
                for (let i = 0; i < array.length; i++) {
                    array[i] += (Math.random() - 0.5) * 0.25;
                }
            };
            const origGetByteFrequencyData = analyser.getByteFrequencyData;
            analyser.getByteFrequencyData = function(array) {
                origGetByteFrequencyData.apply(this, arguments);
                for (let i = 0; i < array.length; i++) {
                    array[i] = Math.max(0, Math.min(255, array[i] + Math.floor((Math.random() - 0.5) * 4)));
                }
            };
            return analyser;
        };
        console.log('✅ Audio fingerprint protection active (noise added)');
    })();
    // ========================================================
    // 4. WEBRTC - PROTECT LOCAL IP ADDRESS LEAK
    // ========================================================
    (function protectWebRTC() {
        if (!window.RTCPeerConnection) return;
        const OrigRTCPeerConnection = window.RTCPeerConnection;
        window.RTCPeerConnection = function(config) {
            const pc = new OrigRTCPeerConnection(config);
            function isLocalCandidate(candidateStr) {
                if (!candidateStr) return false;
                const c = candidateStr.toLowerCase();
                return c.includes('host') ||
                       /\b(192\.168\.|10\.|172\.(1[6-9]|2[0-9]|3[0-1])\.|169\.254\.|fe80::|::1|fc00::|fd00::|local)\b/.test(c);
            }
            let userHandler = null;
            Object.defineProperty(pc, 'onicecandidate', {
                configurable: true,
                set: function(handler) {
                    userHandler = handler;
                    pc._wrappedIceHandler = function(evt) {
                        if (evt && evt.candidate && evt.candidate.candidate) {
                            if (isLocalCandidate(evt.candidate.candidate)) {
                                console.log('%c[Spoof] Blocked local WebRTC candidate (LAN IP leak prevented)', 'color:#f66');
                                return;
                            }
                        }
                        if (userHandler) userHandler.call(pc, evt);
                    };
                },
                get: function() { return userHandler; }
            });
            const origAddEL = pc.addEventListener;
            pc.addEventListener = function(type, listener, opts) {
                if (type === 'icecandidate' && typeof listener === 'function') {
                    const wrapped = function(evt) {
                        if (evt && evt.candidate && evt.candidate.candidate) {
                            if (isLocalCandidate(evt.candidate.candidate)) {
                                console.log('%c[Spoof] Blocked local WebRTC candidate via listener', 'color:#f66');
                                return;
                            }
                        }
                        listener.call(this, evt);
                    };
                    return origAddEL.call(this, type, wrapped, opts);
                }
                return origAddEL.apply(this, arguments);
            };
            return pc;
        };
        window.RTCPeerConnection.prototype = OrigRTCPeerConnection.prototype;
        console.log('✅ WebRTC local IP protection active');
    })();
    // ========================================================
    // 5. PERFORMANCE TIMERS + MEASUREMENTS SPOOF
    // ========================================================
    (function spoofPerformance() {
        const origNow = performance.now.bind(performance);
        let baseOffset = (Math.random() - 0.5) * 20;
        performance.now = function() {
            const t = origNow();
            return t + baseOffset + (Math.random() - 0.5) * 0.04;
        };
        console.log('✅ Performance timers + measurements spoofed (noise + rich memory)');
    })();
    // ========================================================
    // 6. INTERNET BANDWIDTH / NETWORK INFORMATION SPOOF (strengthened)
    // ========================================================
    (function spoofNetwork() {
        let conn = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
        if (!conn) {
            conn = {};
            Object.defineProperty(navigator, 'connection', { value: conn, configurable: true });
        }
        try {
            Object.defineProperties(conn, {
                downlink: { get: () => 2500, configurable: true },
                downlinkMax: { get: () => 10000, configurable: true },
                effectiveType: { get: () => '4g', configurable: true },
                rtt: { get: () => 4, configurable: true },
                saveData: { get: () => false, configurable: true },
                type: { get: () => 'ethernet', configurable: true }
            });
        } catch(e) {
            console.warn('Network spoof partial');
        }
        console.log('✅ Network spoofed: 2.5Gbps+ blazing fast connection');
    })();
    // ========================================================
    // 7. BATTERY ALWAYS FULL (100% + charging)
    // ========================================================
    (function spoofBattery() {
        if (!('getBattery' in navigator)) return;
        navigator.getBattery = function() {
            return Promise.resolve({
                level: 1.0,
                charging: true,
                chargingTime: 0,
                dischargingTime: Infinity,
                addEventListener: () => {},
                removeEventListener: () => {},
                dispatchEvent: () => false
            });
        };
        console.log('✅ Battery spoofed: always 100% + charging');
    })();
    // ========================================================
    // WEBGL VENDOR/RENDERER SPOOF (enhanced)
    // ========================================================
    (function spoofWebGL() {
        const fakeVendor = "Google Inc.";
        const fakeRenderer = "ANGLE (NVIDIA, NVIDIA GeForce RTX 4090 Ti SUPER Direct3D12 vs_6_0 ps_6_0, D3D12)";
        function hookWebGL() {
            const origGetContext = HTMLCanvasElement.prototype.getContext;
            HTMLCanvasElement.prototype.getContext = function(type, attrs) {
                if (!type || !type.includes('webgl')) {
                    return origGetContext.apply(this, arguments);
                }
                const gl = origGetContext.apply(this, arguments);
                if (!gl) return gl;
                const origGetParam = gl.getParameter.bind(gl);
                gl.getParameter = function(param) {
                    if ([0x1F00, 37445].includes(param)) return fakeVendor;
                    if ([0x1F01, 37446].includes(param)) return fakeRenderer;
                    if (param === 0x0D33) return 32768;
                    if (param === 0x0D32) return 32768;
                    return origGetParam(param);
                };
                const origGetExt = gl.getExtension.bind(gl);
                gl.getExtension = function(name) {
                    const ext = origGetExt(name);
                    if (ext && name === 'WEBGL_debug_renderer_info') {
                        ext.getParameter = gl.getParameter.bind(gl);
                    }
                    return ext;
                };
                return gl;
            };
        }
        hookWebGL();
        window.addEventListener('load', hookWebGL);
        setInterval(hookWebGL, 1200);
    })();
    console.log('✅ All spoofs activated! Rich PC + strong anti-fingerprinting ready.');
`);